# Defesa de Arquitetura de Software — Pull Request

## Autor do PR
- **Nome do Estudante:** Vitor Silva
- **Artefato(s) de Responsabilidade:** Diagrama de Sequência, Diagrama de Atividades (raias, fork/join), Máquina de Estados, C4 Nível 2 (Structurizr DSL) e ADR 0001 — Negociação B2B (UC07, UC08, UC09) do Marketplace de Sobras Industriais do Polo CIC

## O que este PR introduz na Documentação Viva?
- [ ] **Visão Funcional / Estrutural:** Diagrama de Casos de Uso ou Diagrama de Classes e Interfaces. *(não incluído: o Diagrama de Classes é da Sprint 2)*
- [x] **Visão Comportamental:** `docs/diagrams/sequencia.mmd`, `atividades.mmd` e `estados.mmd`
- [x] **Visão Arquitetural Macro:** `docs/architecture/workspace.dsl` (C4 L1 e L2)
- [x] **Governança:** `docs/adr/adr-0001.md` (movido de `docs/architecture/`)

Correções desta rodada:
- `sequencia.mmd`: removido `;` no texto de um `Note` (quebrava o parser) e adicionados `tb_outbox` e `OutboxRelay` à publicação do evento de acordo.
- `estados.mmd`: `entry/do/exit` movidos para notas ancoradas (o Mermaid rejeita descrição em estado composto); `TermosConsensados` agora é estado de topo e há a transição de colisão `TermosConsensados → InterrompidaPorTerceiro`.
- `atividades.mmd`: o ramo C do fork grava o evento na `tb_outbox`; a publicação no RabbitMQ ocorre depois do join e do commit.
- README sincronizado com os `.mmd`, com a correspondência `StatusNegociacao` ↔ estados (seção 5.4).
- ADR: nomes de estados padronizados e redação de "overbooking" ajustada.

## Defesa das Decisões de Design (Justificativa Técnica)
1. **Escolha de Abstrações e Desacoplamento:** `NegociacaoController` → `NegociacaoService` → entidades `Negociacao` e `Oferta` mantêm a regra de negócio no domínio (Padrão State), e a infraestrutura (RabbitMQ, Outbox Relay, notificações) fica atrás de mensageria assíncrona. O Core Backend não conhece o Worker NestJS, só publica eventos.
2. **Dinâmica e Resiliência:** os fluxos `alt/else` da sequência cobrem amostra (UC09), aceite mútuo e cancelamento. No aceite, a colisão de `@Version` em `Oferta` leva a `INTERROMPIDA_POR_TERCEIRO`. As guardas de estado (`rodada < 3`, `saldoEstoqueSuficiente`, SLA de 48h) impedem transições inválidas. O Outbox evita a dupla escrita entre PostgreSQL e RabbitMQ.
3. **Trade-offs:** bloqueio otimista dá alto throughput em negociações longas, mas exige tratar a falha de concorrência para o usuário. O Outbox adiciona complexidade (relay, DLQ) em troca de consistência entre banco e broker. Só o evento crítico `negociacao.acordo.firmado` usa Outbox, e os demais são publicados direto.

## Consistência Cross-Diagramas (Checklist de Autoverificação)
- [ ] Os nomes de métodos chamados no Diagrama de Sequência existem nas interfaces do Diagrama de Classes. *(conferir contra o Diagrama de Classes da Sprint 2)*
- [ ] Os contêineres e componentes citados correspondem exatamente à nomenclatura do Modelo C4 L2/L3.
- [x] As transições de estado refletem os gatilhos disparados pelas atividades da aplicação.

## Validação da Sintaxe Diagrams-as-Code / Models-as-Code
- **Ferramenta de Compilação/Renderização Utilizada:** Mermaid CLI (`mmdc`) para os 3 `.mmd`; Structurizr CLI (`structurizr-cli validate -w APS3/docs/architecture/workspace.dsl`) para o DSL
- **Status da Compilação:** [ ] Código limpo e sem erros de sintaxe ao renderizar. *(marcar depois de rodar o `structurizr-cli validate`)*
